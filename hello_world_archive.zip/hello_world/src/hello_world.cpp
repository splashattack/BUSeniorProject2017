//============================================================================
// Name        : hello_world.cpp
// Author      : author
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "Hello, world!" << endl; // prints Hello, world!
	return 0;
}
